#!/bin/bash

# NXOLand Backend Deployment Script
cd /home/ploi/api.nxoland.com

# Install/update Composer dependencies
composer install --no-dev --optimize-autoloader

# Set proper permissions
chmod -R 755 public/
chmod 644 public/.htaccess
chmod 644 public/index.php

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    cat > .env << 'ENVEOF'
APP_NAME=NXOLand API
APP_ENV=production
APP_DEBUG=false
APP_URL=https://api.nxoland.com

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=nxoland
DB_USERNAME=your_username
DB_PASSWORD=your_password

JWT_SECRET=your_jwt_secret_key_here
JWT_ALGORITHM=HS256
ENVEOF
fi

# Reload PHP-FPM
echo "" | sudo -S service php8.4-fpm reload

echo "Backend API deployed successfully!"
